import { AppRegistry, UIManager } from 'react-native';
import App from './src/App.js';

UIManager.setLayoutAnimationEnabledExperimental(true);
AppRegistry.registerComponent('SquirrelStreetAustralia', () => App);
