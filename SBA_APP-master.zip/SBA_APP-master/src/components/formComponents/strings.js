
export const helpURL = 'https://id.sbaustralia.com/reset';
export const termsURL = 'https://id.sbaustralia.com/terms-of-service';
export const privacyURL = 'https://id.sbaustralia.com/privacy';

export const LoginButtonText = 'Log In!';
