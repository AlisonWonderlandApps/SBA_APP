/*
* mainComponents styles
*/

export const mainStyles = {
  cardSection: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 10,
  },
  mapContainer: {

  },
  map: {

  }
};
