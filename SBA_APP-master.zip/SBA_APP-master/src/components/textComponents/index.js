
export * from './HeaderText';
export * from './LinkText';
export * from './SmallText';
export * from './SubtitleText';
export * from './TitleText';
export * from './ErrorText';
export * from './ButtonText';
export * from './FormText';
export * from './BannerText';
export * from './ColourText';
export * from './CentreText';
export * from './SettingsText';
