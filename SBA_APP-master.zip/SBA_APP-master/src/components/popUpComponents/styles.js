/*
* popUpComponents styles
*/
