
export const MainScreenStyles = {
  containerStyle: {
    flex: 1,
    padding: 10
  }
};
