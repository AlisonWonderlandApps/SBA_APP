// styles index

export * from './SplashScreenStyle';
export * from './LoadingOverlayStyle';
export * from './MainScreenStyles';

export const AppIntroStyle = {
  containerStyle: {
    flex: 1
  },
  imageStyle: {

  },
  titleStyle: {

  },
  textStyle: {

  }

};
