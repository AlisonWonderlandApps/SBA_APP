/*** LoginAction Strings ***/

export const AlertErrorTitleStr = 'Oops!!!\nLoginFailed :(\n';
export const okStr = 'OK';
export const loginFailedStr = 'Please check your email and password';
