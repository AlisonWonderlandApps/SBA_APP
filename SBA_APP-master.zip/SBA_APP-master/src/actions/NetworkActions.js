/*
* All actions pertaining to network connectivity
* and offline use
*/

//1. Check connectivity

//2. check local database cache against web server

//3.

//4.
