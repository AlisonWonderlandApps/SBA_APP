/*
* All actions a user can take pertaining to settings
*/

//1. Change Account type

//2. Camera on/off

//3. logout
