/*
* All actions pertaining to a user session
*/

//1. Sync all actions with web server

//2. Put unprocessed actions in a queue

//3.

//4. Logout?
