//image paths

export const MAIN_LOGO = '../assets/SquirrelStreet_logo_col_rev_stacked_RGB.png';
