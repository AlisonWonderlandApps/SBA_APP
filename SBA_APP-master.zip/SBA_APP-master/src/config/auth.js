export const ssAuthConfig = {
    clientId: 'SBA_MOBILE_APP',
    clientSecret: '55XKH70Y9x66h1FHaDDFI3u2Mu1PKf8e1dJf8la1x1KAQ8tL',
    tokenURL: 'https://id.squirrelstreet.com/oauth/token',
    clientGrantType: 'client_credentials',
    refreshTokenGrantType: 'refresh_token',
    userGrantType: 'password',
    demoEmail: 'xerodemo@null.com',
    demoPassword: 'W1QKbBcbT8',
    scopeAll: 'all',
    scopeInternal: 'internal'
};

export const googleAuth = {

};

export const facebookAuth = {

};

export const ssApiQueryURL = {
    user: 'https://api.squirrelstreet.com:443/v2/user/',
    userAccounts: 'https://api.squirrelstreet.com:443/v2/user/accounts/',
    accounts: 'https://api.squirrelstreet.com:443/v2/accounts/',
    rootURL: 'https://api.squirrelstreet.com:443/v2/'
    accountsSquirrel : 'https://api.squirrelstreet.com/v2/accounts/'

};
